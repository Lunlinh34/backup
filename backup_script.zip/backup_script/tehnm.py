import os
import shutil
import smtplib
import schedule
import time
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from dotenv import load_dotenv
from datetime import datetime

# Load environment variables
load_dotenv()

MAIL_SENDER = os.getenv('MAIL_SENDER')
MAIL_PASSWORD = os.getenv('MAIL_PASSWORD')
MAIL_RECEIVER = os.getenv('MAIL_RECEIVER')

# Path settings
SOURCE_DIR = './'   # thư mục chứa các file .sql, .sqlite3
BACKUP_DIR = './backups'

def send_email(subject, body):
    """Gửi email báo cáo."""
    try:
        message = MIMEMultipart()
        message['From'] = MAIL_SENDER
        message['To'] = MAIL_RECEIVER
        message['Subject'] = subject

        message.attach(MIMEText(body, 'plain'))

        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(MAIL_SENDER, MAIL_PASSWORD)
        server.send_message(message)
        server.quit()

        print('Email đã được gửi.')
    except Exception as e:
        print('Gửi email thất bại:', e)

def backup_database():
    """Backup file database .sql và .sqlite3"""
    try:
        os.makedirs(BACKUP_DIR, exist_ok=True)
        now = datetime.now().strftime('%Y%m%d_%H%M%S')
        files_backed_up = []

        for filename in os.listdir(SOURCE_DIR):
            if filename.endswith('.sql') or filename.endswith('.sqlite3'):
                src_path = os.path.join(SOURCE_DIR, filename)
                backup_filename = f"{now}_{filename}"
                dst_path = os.path.join(BACKUP_DIR, backup_filename)
                shutil.copy2(src_path, dst_path)
                files_backed_up.append(backup_filename)

        if files_backed_up:
            subject = 'Backup Thành Công ✅'
            body = f"Các file sau đã được backup lúc {now}:\n\n" + "\n".join(files_backed_up)
        else:
            subject = 'Backup Thất Bại ⚠️'
            body = "Không tìm thấy file .sql hoặc .sqlite3 nào để backup."

        send_email(subject, body)

    except Exception as e:
        subject = 'Backup Lỗi ❌'
        body = f"Có lỗi xảy ra trong quá trình backup:\n\n{str(e)}"
        send_email(subject, body)

def job():
    print("Bắt đầu backup lúc", datetime.now())
    backup_database()

# Schedule công việc mỗi ngày lúc 00:00
schedule.every().day.at("00:00").do(job)

print("Script backup đang chạy...")

while True:
    schedule.run_pending()
    time.sleep(60)
